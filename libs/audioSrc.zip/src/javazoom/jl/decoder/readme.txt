
TODO:


Implement high-level Player and Converter classes.

Add MP1 and MP2 support and test. 

Add option to run each "stage" on own thread. 
E.g. read & parse input, decode subbands, subband synthesis, audio output.

Retrofit seek support (temporarily removed when reworking classes.)


Document and give example code. 